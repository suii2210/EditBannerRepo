"use client";
import React, { useState, useEffect } from "react";

export const BottomSheet = ({ isOpen, onClose, selectedBanner, onSave }:{
  isOpen?:any;
  onClose?:any;
  selectedBanner?:any;
  onSave?:any;
}) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");

  useEffect(() => {
    if (selectedBanner) {
      setTitle(selectedBanner.title);
      setDescription(selectedBanner.description);
      setImage(selectedBanner.image);
    }
  }, [selectedBanner]);

  const handleSave = () => {
    const updatedBanner = { ...selectedBanner, title, description, image };
    onSave(updatedBanner);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Edit Banner</h2>
          <button onClick={onClose}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        <div className="mb-4 flex flex-col items-center">
          <div className="w-full flex justify-center mb-2">
            <img src={image} alt={title} className="w-64 h-40 object-cover rounded" />
          </div>
          <p className="text-sm text-gray-600">
            Image Attribution: Photo by Xu Haiwei on Unsplash
          </p>
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Images</label>
          <div className="flex space-x-2 overflow-x-scroll">
            {['/img1.jpg', '/img2.jpg', '/img3.jpg', '/img4.jpg', '/img5.jpg', '/img6.jpg'].map((img, index) => (
              <button key={index} onClick={() => setImage(img)} className="focus:outline-none">
                <img src={img} alt={`Thumbnail ${index}`} className={`w-10 h-10 object-cover rounded-full ${image === img ? 'ring-2 ring-blue-500' : ''}`} />
              </button>
            ))}
            <button className="focus:outline-none">
              <div className="w-10 h-10 flex items-center justify-center border rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 5a1 1 0 01.993.883L11 6v3h3a1 1 0 01.117 1.993L14 11h-3v3a1 1 0 01-1.993.117L9 14v-3H6a1 1 0 01-.117-1.993L6 9h3V6a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
              </div>
            </button>
          </div>
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-bold mb-2">Description</label>
          <input
          
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
        <div className="flex justify-end">
          <button onClick={handleSave} className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

export default BottomSheet;
