"use client";
import React, { useState } from "react";
import { adBanners as initialAdBanners } from "@/data/index";
import BottomSheet from "./BottomSheet";

interface Banner {
  id: number;
  title: string;
  description: string;
  backgroundImage: string;
  url: string;
  cta: string;
  image: string;
}

const Home = () => {
  const [adBanners, setAdBanners] = useState<Banner[]>(initialAdBanners);
  const [selectedBanner, setSelectedBanner] = useState<Banner | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleEdit = (banner: Banner) => {
    setSelectedBanner(banner);
    setIsOpen(true);
  };

  const handleSave = (updatedBanner: Banner) => {
    const updatedAdBanners = adBanners.map((banner) =>
      banner.id === updatedBanner.id ? updatedBanner : banner
    );

    setAdBanners(updatedAdBanners);
    setIsOpen(false);
  };

  const imageShapes = [
    "rounded-full m-0 p-0",
    "rounded-3xl",
    "rounded-full",
    "rounded-full",
    "rounded-3xl",
    "rounded-md",
    "rounded-sm",
    "rounded-none",
  ];

  return (
    <div className="bg-black">
      <div className="container mx-auto p-2 pt-0 md:p-6 lg:p-0 xl:p-0 w-full">
        <h1 className="text-3xl font-bold mb-4 text-white">Ad Banners</h1>
        <ul className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
          {adBanners.map((banner, index) => (
            <li
              key={banner.id}
              className={`banner-${index} rounded max-full shadow-md p-4 border-cyan-400 border`}
              style={{ backgroundImage: `url(${banner.backgroundImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
            >
              <div className="ad-banner-content">
                <button
                  className="text-gray-500 hover:text-gray-700 align-top mb-3 ml-7 mt-6"
                  onClick={() => handleEdit(banner)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-10 w-10"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 21v-3.75L14.06 6.19l3.75 3.75L6.75 21H3zm2.25-2.25H5v-.75H4.25v.75h.75v.75h.75v-.75zm.84-1.41L3 21v-3.75l10.19-10.19 3.75 3.75L6.09 17.34zM14.06 9.44L12.75 8.12l3.75-3.75 1.31 1.31-3.75 3.75zM17.19 6.31l-1.31-1.31 1.06-1.06a1.5 1.5 0 012.12 0l.94.94a1.5 1.5 0 010 2.12l-1.06 1.06-1.31-1.31 1.06-1.06-.94-.94a.75.75 0 00-1.06 0l-1.06 1.06z" 
                    />
                  </svg>
                </button>
                <div className="top-24 left-7 relative">
                  <h2 className="text-3xl font-bold mb-7 top-56 text-white">{banner.title}</h2>
                  <p className="text-black-500 mb-4 text-white text-xl ">{banner.description}</p>
                </div>
              </div>
              <div className="flex flex-row">
                <a
                  href={banner.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold px-2 py-2 rounded h-16 w-32 mx-8 mt-64"
                >
                  <button className="">{banner.cta}</button>
                </a>
                <img
                  src={banner.image}
                  alt={banner.title}
                  className={`w-72 h-72 ${imageShapes[index % imageShapes.length]} pr-0 ml-56 relative bottom-10`}
                />
              </div>
            </li>
          ))}
        </ul>
        <BottomSheet
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          selectedBanner={selectedBanner}
          onSave={handleSave}
        />
      </div>
    </div>
  );
};

export default Home;
