
 export const  adBanners = [
  {
    id: 1,
    title: 'Boost Your Leads',
    description: 'Hamess AI for Effective Compaigns',
    cta: 'Learn More',
    image: 'banner1.jpg',
    background: 'bg-blue',
    url: 'https://www.example.com/banner1',
    backgroundImage:'backImg1.jpg',

  },
  {
    id: 2,
    title: 'Boost Your Leads',
    description: 'Hamess AI for Effective Compaigns',
    cta: 'Learn More',
    image: 'banner2.jpg',
    background: 'bg-green',
    url: 'https://www.example.com/banner2',
    backgroundImage:'backImg2.jpg',

  },
  {
    id: 3,
    title: 'Boost Your Leads',
    description: 'This is the third banner',
    cta: 'Get Started',
    image: 'banner3.jpg',
    background: 'bg-orange',
    url: 'https://www.example.com/banner3',
    backgroundImage:'backImg3.jpg',

  },
  {
    id: 4,
    title: 'Boost Your Leads',
    description: 'This is the third banner',
    cta: 'Get Started',
    image: 'banner4.jpg',
    background: 'bg-orange',
    url: 'https://www.example.com/banner3',
    backgroundImage:'backImg4.jpg',

  },
  {
    id: 5,
    title: 'Boost Your Leads',
    description: 'This is the third banner',
    cta: 'Get Started',
    image: 'banner5.jpg',
    background: 'bg-orange',
    url: 'https://www.example.com/banner3',
    backgroundImage:'backImg5.jpg',

  },
  {
    id: 6,
    title: 'Boost Your Leads',
    description: 'This is the third banner',
    cta: 'Get Started',
    image: 'banner6.jpg',
    background: 'bg-orange',
    url: 'https://www.example.com/banner3',
    backgroundImage:'backImg6.jpg',

  },
  // Add more ad banners to the list as needed
];
