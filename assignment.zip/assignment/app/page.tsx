import React from 'react'
import Home from '@/components/Home'
import BottomSheet from '@/components/BottomSheet'

const page = () => {
  return (
    
   <Home/>

  )
}

export default page
